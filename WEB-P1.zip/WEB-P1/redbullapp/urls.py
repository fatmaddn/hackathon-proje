from django.urls import path 
from .views import homePage , energydrinkPage,loginPage,RegisterPage,urunListesi,urunKategori, siparisler,iller,ilceler,developerAPage
from .views import logout_view  # Oturumdan çıkış view'ını import


urlpatterns = [
    path('',homePage , name="HomePage"),
    
    path('energydrink/',energydrinkPage,name="energydrinkPage"),
    path('developerContent/',developerAPage,name="developerAPage"),
    path('login/',loginPage,name='loginPage'),

    path('registerPage/',RegisterPage,name='RegisterPage'),

    path('redbullApi/urunlerapi/',urunListesi),

    path('redbullApi/urunKategorileri/',urunKategori),

    path('redbullApi/siparisler/',siparisler),

    path('redbullApi/iller/',iller),

    path('redbullApi/ilceler/',ilceler),
]

