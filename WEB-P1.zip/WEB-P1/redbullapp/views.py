from django.shortcuts import render, redirect
from .models import Kullanici, Il, Ilce , Urunler ,UrunKategori ,Siparis

from django.contrib.auth import authenticate, login, logout


from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializer import UrunlerSerializer,UrunKategoriSerializer , SiparisSerializer ,IlSerializer,IlceSerializer


from django.db import connection


# Create your views here.
from django.contrib.auth import authenticate , login , logout


def homePage(request):
    return render(request, 'index.html')


def developerAPage(request):
    return render(request, 'templates/partials/developer.html')
    

def energydrinkPage(request):
    products = Urunler.objects.all()

    total_count = products.count()  # Sorgu kümesindeki toplam öğe sayısını alır
    context = {
        'products':products,
        'total_count':total_count
    }
    return render(request, 'templates/partials/energydrink.html',context)



def loginPage(request):

    if request.method == 'POST':
        username = request.POST['u_name']
        password = request.POST['u_password']

        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM Kullanici WHERE kull_ad = %s AND kull_sifre = %s", [username, password])
            user = cursor.fetchone()


        if user:
            # Kullanıcı bulundu, kullanıcıyı ana sayfaya yönlendir
            return redirect('HomePage')
        
        else:
            # Kullanıcı bulunamadı, hata mesajı göster
            return render(request, 'partials/login.html', {'error': 'Kullanıcı adı veya şifre hatalı'})
    else:
        return render(request, 'templates/partials/login.html')

    # return render(request, 'partials/login.html')
def RegisterPage(request):

     # Kullanıcı oturum açmışsa, ana sayfaya yönlendirin
    if request.user.is_authenticated:  # Kullanıcı giriş yapmışsa
        return redirect('HomePage')  # Ana sayfaya yönlendirme

    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        city_name = request.POST['city']
        district_name = request.POST['district']

        city = Il.objects.get(il_ad=city_name)  

        district = Ilce.objects.filter(ilce_ad=district_name).first() 


        if Kullanici.objects.filter(kull_ad = username).exists():
                return render(request , 'templates/partials/register.html',{"error":"username kullanılıyor",
                "username":username,
                "email":email
                })

        if Kullanici.objects.filter(kull_mail=email).exists():
                return render(request , 'templates/partials/register.html',{
                    "error":" email kullanılıyor",
                    "username":username,
                    "email":email
                    })

        user = Kullanici.objects.create(kull_ad=username , kull_mail=email , kull_sifre=password,kull_il=city,kull_ilce=district)

        user.save()
        return redirect('HomePage')
    else:
        return render(request , 'templates/partials/register.html')

    # return render(request,'partials/register.html')

#  For APİ


def logout_view(request):
    # Kullanıcıyı oturumdan çıkar
    logout(request)
    # Kullanıcıyı login sayfasına veya ana sayfaya yönlendir
    return redirect('loginPage')  # 'loginPage' uygun yönlendirme örneği


@api_view(['GET'])
def urunListesi(request):
    urunler = Urunler.objects.all()
    serializer = UrunlerSerializer(urunler,many=True) 
    return Response(serializer.data)


@api_view(['GET'])
def urunKategori(request):
    urunKategorileri = UrunKategori.objects.all()

    serializer = UrunKategoriSerializer(urunKategorileri,many=True) 
    return Response(serializer.data)


@api_view(['GET'])
def siparisler(request):
    siparislerr = Siparis.objects.all()
    serializer = SiparisSerializer(siparislerr,many=True) 
    return Response(serializer.data)


@api_view(['GET'])
def iller(request):
    il = Il.objects.all()
    serializer = IlSerializer(il,many=True)
    return Response(serializer.data)


@api_view(['GET'])
def ilceler(request):
    ilce = Ilce.objects.all()
    serializer = IlceSerializer(ilce,many=True)
    return Response(serializer.data)
