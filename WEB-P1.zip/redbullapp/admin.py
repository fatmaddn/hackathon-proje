from django.contrib import admin

from .models import  Kullanici , Urunler , UrunKategori

admin.site.register(Kullanici)
admin.site.register(Urunler)
admin.site.register(UrunKategori)