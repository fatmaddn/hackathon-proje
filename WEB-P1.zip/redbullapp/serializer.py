from rest_framework import serializers
from .models import Urunler, UrunKategori ,Kullanici,Siparis,Il,Ilce

class UrunlerSerializer(serializers.Serializer):
    urun_id = serializers.IntegerField()  # `AutoField` yerine `IntegerField`
    urun_ad = serializers.CharField(max_length=45)
    urun_aciklama = serializers.CharField(max_length=100)
    urun_fiyat = serializers.DecimalField(max_digits=10, decimal_places=0, required=False)  # `blank` yerine `required=False`
    urun_stok = serializers.IntegerField(required=False)
    kdv_orani = serializers.DecimalField(max_digits=10, decimal_places=0, required=False)
    urun_resim = serializers.CharField(max_length=45, required=False)
    
    # Yabancı anahtar ilişkisi için `PrimaryKeyRelatedField` veya `SlugRelatedField`
    urun_kategori = serializers.PrimaryKeyRelatedField(
        queryset=UrunKategori.objects.all(),  # İlişkinin hangi modelden geldiğini belirtin
        required=False  # Bu alanın boş bırakılmasına izin ver
    )


class UrunKategoriSerializer(serializers.Serializer):  # Serializer adını düzeltildi
    kategori_id = serializers.IntegerField()  # AutoField yerine IntegerField
    kategori_ad = serializers.CharField(max_length=45, required=False)  # `blank` yerine `required=False`




class SiparisSerializer(serializers.ModelSerializer):  # ModelSerializer kullanın
    # Yabancı anahtar ilişkileri için `PrimaryKeyRelatedField`
    alinan_urun = serializers.PrimaryKeyRelatedField(queryset=Urunler.objects.all(), required=False)
    alan_kull = serializers.PrimaryKeyRelatedField(queryset=Kullanici.objects.all(), required=False)
    
    class Meta:
        model = Siparis  # Hangi modelden serializer oluşturulacak
        fields = [
            'siparis_id',  # Birincil anahtar
            'alinan_urun',  # Yabancı anahtar
            'alan_kull',  # Yabancı anahtar
            'time',  # Tarih alanı
            'kull_adres',  # Metin alanı
            'kull_il',  # Yabancı anahtar
            'kull_ilce',  # Yabancı anahtar
        ]



class IlSerializer(serializers.ModelSerializer):
    class Meta:
        model = Il  # Model tabanlı serializer oluşturulacak
        fields = ['il_id', 'il_ad']  # İlgili alanları belirtin




class IlceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ilce
        fields = ['ilce_id', 'ilce_ad']  # İlgili alanları belirtin