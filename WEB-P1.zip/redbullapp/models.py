from django.db import models



class Il(models.Model):
    il_id = models.AutoField(primary_key=True)
    il_ad = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'il'


class Ilce(models.Model):
    ilce_id = models.AutoField(primary_key=True)
    ilce_ad = models.CharField(max_length=45, blank=True, null=True)
    il_ilce = models.ForeignKey(Il, models.DO_NOTHING, db_column='il_ilce', blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'ilce'


class Kullanici(models.Model):
    kull_id = models.AutoField(primary_key=True)
    kull_ad = models.CharField(max_length=50)
    kull_mail = models.CharField(max_length=50)
    kull_sifre = models.CharField(max_length=50)
   
    kull_il = models.OneToOneField(Il, models.DO_NOTHING, blank=True, null=True)
    kull_ilce = models.OneToOneField(Ilce, models.DO_NOTHING, blank=True, null=True)


    class Meta:
        managed = True
        db_table = 'kullanici'


class Siparis(models.Model):
    siparis_id = models.AutoField(primary_key=True)
    alinan_urun = models.ForeignKey('Urunler', models.DO_NOTHING, blank=True, null=True)
    alan_kull = models.ForeignKey(Kullanici, models.DO_NOTHING, blank=True, null=True)
    time = models.DateField(blank=True, null=True)
    kull_adres = models.CharField(max_length=100, blank=True, null=True)
   
    kull_il = models.OneToOneField(Kullanici, models.DO_NOTHING, db_column='kull_il', to_field='kull_il_id', related_name='siparis_kull_il_set', blank=True, null=True,unique=True)
    kull_ilce = models.OneToOneField(Kullanici, models.DO_NOTHING, db_column='kull_ilce', to_field='kull_ilce_id', related_name='siparis_kull_ilce_set', blank=True, null=True,unique=True)


    class Meta:
        managed = True
        db_table = 'siparis'


class UrunKategori(models.Model):
    kategori_id = models.AutoField(primary_key=True)
    kategori_ad = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'urun_kategori'


class Urunler(models.Model):
    urun_id = models.AutoField(primary_key=True)
    urun_ad = models.CharField(max_length=45)
    urun_aciklama = models.CharField(max_length=100)
    urun_fiyat = models.DecimalField(max_digits=10, decimal_places=0, blank=True, null=True)
    urun_stok = models.IntegerField(blank=True, null=True)
    kdv_orani = models.DecimalField(max_digits=10, decimal_places=0, blank=True, null=True)
    urun_resim = models.CharField(max_length=45, blank=True, null=True)
    urun_kategori = models.ForeignKey(UrunKategori, models.DO_NOTHING, db_column='urun_kategori', blank=True, null=True)

    class Meta:
        managed = True;
        db_table = 'urunler'
