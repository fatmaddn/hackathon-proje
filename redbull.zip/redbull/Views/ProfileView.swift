//
//  ProfileView.swift
//  redbull
//
//  Created by Hilal Öner on 4/27/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ProfileView()
}
